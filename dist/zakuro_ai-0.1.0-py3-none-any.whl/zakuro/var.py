__ZAKURO_URI__='zakuro'
__DASK__ = "dask"
__SPARK__ = "spark"
__FILESTORE__="FileStore"
__ZFS_URI__="zfs"